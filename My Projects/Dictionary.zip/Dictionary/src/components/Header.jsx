export default function Header() {
    return (
        <header className="header">
            <h1>ОКТИШКИ ГОВОР (АРХАИЧНИ ЛАФОЈ)</h1>
        </header>
    );
}