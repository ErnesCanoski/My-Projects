

//components
import Header from './components/Header.jsx';
import Navbar from './components/Navbar.jsx';
import Cards from './components/Cards.jsx';
import NewCardComponent from './components/NewCardComponent.jsx';
import Counter from './components/Counter.jsx';

function App() {

  return (
    <>
      <Header />
      <Navbar />
      <div className='cards' >
        <Cards
          name="Ernes"
          lastName="Canoski"
          age="23"
          index="17760"
          isStudent={true}
        />


        <Cards
          name="Ernes"
          lastName="Canoski"
          age="23"
          index="17760"
          isStudent={true}
        />
        <Cards
          name="Bob"
          lastName="Bobski"
          age="55"
          index="N/A"
          isStudent={false}
        />
        <Cards
          name="Ergin"
          lastName="Canoski"
          age="25"
          index="15521"
          isStudent={true}
        />
        <Cards
          name="Tihomir"
          lastName="Milenkovic"
          age="28"
          index="324543"
          isStudent={false}
        />

      </div>

      <>
      <NewCardComponent/>
      </>

      <>
        <Counter/>
      </>


    </>
  )
}

export default App
