import '../styles/header.css';

function Header() {
    return (

        <header className='header'>
            <h1 className='title'>American University Of Europe FON</h1>
        </header>

    );
}

export default Header;