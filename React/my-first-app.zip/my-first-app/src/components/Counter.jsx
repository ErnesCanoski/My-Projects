import React, { useState } from 'react';
import '../styles/counter.css';

function Counter() {

    const [counter, setcounter] = useState(0);


  function handleCounterAddition() {
    //ako counter e pomal od 10, togas dodavaj
    if(counter < 10){
      setcounter(counter + 1);
    }
    
  }

  function handleCounterMinus() {
    //ako counter e pogolem od nula, togas minusiraj 
    if (counter > 0) {
      setcounter(counter - 1);
    }
  }

    return(
        <div className='counter'>
        <button onClick={handleCounterAddition}><h1>+</h1></button>
        <span><h1>{counter}</h1></span>
        <button onClick={handleCounterMinus}><h1>-</h1></button>
      </div>
    );
}




export default Counter;