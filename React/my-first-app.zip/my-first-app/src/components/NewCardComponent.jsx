import { useState } from "react";
import '../styles/newCardComponent.css';


function NewCardComponent(){
    const [elements, setElements] = useState({
        firstName: "Kevin",
        secondName: "Punter"
    });

    function handleElements(){
        setElements({...elements, firstName:"Trust", secondName: "Him"})
    }
    return(
        <div className="elements">
        <h1 className="firstName">{elements.firstName}</h1>
        <h1 className="secondName">{elements.secondName}</h1>

        <button className="btn" onClick={handleElements}>Click Here to change the Elements!</button>
        </div>
    );
}

export default NewCardComponent;