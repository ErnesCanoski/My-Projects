import '../styles/navbar.css';

function Navbar() {

    let navElements = ["Home", "About us", "Concact us", "Services", "Blog"];

    return (


        <nav className='nav'>
            <h1>Logo</h1>
            
            <ul>
                {navElements.map((nav,index) => {
                   return <li key = {index}>{nav}</li>
                })}
            </ul>
        </nav>
    );
}

export default Navbar;