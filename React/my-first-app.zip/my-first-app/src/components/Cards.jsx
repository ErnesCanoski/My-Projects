import '../styles/cards.css';


function Cards(props) {

    return(
        <div className="cardElements">
        <h1>{props.name}</h1>
        <h1>{props.lastName}</h1>
        <h2>{props.age}</h2>
        <h3>{props.index}</h3>
        <h3 className="student">{props.isStudent ? "Student!" : "Not a Student!"}</h3>

        
        </div>
    );
}



export default Cards